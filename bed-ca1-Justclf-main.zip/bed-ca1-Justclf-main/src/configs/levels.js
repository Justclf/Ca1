module.exports = [
    { name: 'E-Hunter', xp: 0 },
    { name: 'D-Hunter', xp: 100 },
    { name: 'C-Hunter', xp: 300 },
    { name: 'B-Hunter', xp: 600 },
    { name: 'A-Hunter', xp: 1000 },
    { name: 'S-Hunter', xp: 1500 }
];